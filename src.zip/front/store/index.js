// src/store/index.js
// 상태 관리 설정 (Redux, Zustand 등)

// Example for a simple context API or Zustand store
// import create from 'zustand';

// const useStore = create(set => ({
//   count: 0,
//   inc: () => set(state => ({ count: state.count + 1 })),
// }));

// export default useStore;

console.log('State management setup goes here.');
