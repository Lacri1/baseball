// src/components/Pitcher.js
import React from 'react';

function Pitcher() {
  return (
    <div>
      <h3>Pitcher Component</h3>
      {/* Pitcher content */}
    </div>
  );
}

export default Pitcher;
