// src/components/Scoreboard.js
import React from 'react';

function Scoreboard() {
  return (
    <div>
      <h2>Scoreboard Component</h2>
      {/* Scoreboard content */}
    </div>
  );
}

export default Scoreboard;
