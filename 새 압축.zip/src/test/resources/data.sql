INSERT INTO member (Id, Pw, Team, Game, Win, Lose, Draw)
VALUES ('u1', 'pw', 'Giants', 0, 0, 0, 0);

INSERT INTO board (category, title, text, writer, view)
VALUES ('notice', 'hello', 'world', 'u1', 0);